---
name: Drizzle ON CONFLICT requires unique constraint
description: onConflictDoUpdate silently fails unless a unique() constraint is declared in the schema and pushed to the DB.
---

# Drizzle ON CONFLICT Requires Explicit Unique Constraint

## Rule
`db.insert(...).onConflictDoUpdate({ target: [...columns] })` throws `there is no unique or exclusion constraint matching the ON CONFLICT specification` unless a `unique(...)` table constraint is declared in the Drizzle schema AND `pnpm --filter @workspace/db run push` has been run.

## Example (threat_stats table)
```typescript
export const threatStatsTable = pgTable(
  "threat_stats",
  { mcc: text("mcc"), mnc: text("mnc"), eventType: text("event_type"), date: text("date"), count: integer("count") },
  (t) => [unique("threat_stats_uniq").on(t.mcc, t.mnc, t.eventType, t.date)]
);
```

**Why:** PostgreSQL ON CONFLICT requires the target columns to be covered by a unique index. Drizzle does not auto-create indexes for onConflictDoUpdate targets — they must be declared explicitly and migrated.

**How to apply:** Any time you write `onConflictDoUpdate`, check that the target columns have a corresponding `unique(...)` in the table definition and have been pushed.
