---
name: Expo SDK 54 companion package versions
description: Correct npm versions for Expo SDK 54 companion packages — wrong versions cause createPermissionHook crashes on web.
---

# Expo SDK 54 Companion Package Versions

## Rule
When installing new Expo companion packages for this project (SDK 54 / expo@54.0.35), use the versions shown in the Expo upgrade warnings, NOT the latest npm version. Installing latest (e.g., 56.x) causes `(0, _expo.createPermissionHook) is not a function` crash on web.

## Correct versions for SDK 54
- `expo-cellular@~8.0.8`
- `expo-network@~8.0.8`
- `expo-local-authentication@~17.0.8`
- `expo-location@~18.0.x` (already installed correctly)
- `expo-device@~8.0.10` (already installed but older)
- `expo-secure-store@~15.0.8` (already installed but older)

**Why:** Expo SDK 54 bundles specific peer-compatible versions. Installing `pnpm add expo-cellular` without a version pin installs latest (56.x) which targets SDK 55/56 APIs not present in SDK 54. The error `createPermissionHook is not a function` is a reliable indicator of this mismatch.

**How to apply:** Always check `expo install expo-<package>` output for expected version warnings, or pin to `~N.0.x` matching the SDK's own companion matrix.
