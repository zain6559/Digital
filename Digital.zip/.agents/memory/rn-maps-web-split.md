---
name: react-native-maps web platform split
description: react-native-maps imports codegenNativeCommands which crashes Metro web bundling even behind Platform.OS checks. Must use file-level platform split.
---

**Rule:** Never import react-native-maps in a shared .tsx file, even conditionally. Metro resolves all static imports before runtime checks.

**Why:** react-native-maps imports `react-native/Libraries/Utilities/codegenNativeCommands` which is a native-only internal. Metro's web bundler errors out on this at bundle time regardless of any `Platform.OS === 'web'` guard.

**How to apply:** Use Expo's platform-specific file resolution:
- `Component.web.tsx` — web version (pure RN primitives, SVG radar, etc.)
- `Component.tsx` — native version (can freely import react-native-maps)

Metro automatically picks the right file per platform. TypeScript typechecks both independently. Dynamic `require()` inside a Platform.OS check does NOT fix this — Metro still resolves the module.
